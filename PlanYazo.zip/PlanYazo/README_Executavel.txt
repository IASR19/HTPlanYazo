PlanYazo - Executável

INSTRUÇÕES DE USO:

1. Certifique-se que os arquivos Plan.xlsx e Yazo.xlsx estão na mesma pasta do executável
2. Dê duplo clique em PlanYazo.exe para executar
3. A interface gráfica será aberta automaticamente

FUNCIONALIDADES:
- 🎤 Palestra: Transfere dados da aba PALESTRA
- 🔧 Workshop: Transfere dados da aba WORKSHOP  
- 👥 Painel: Transfere dados da aba PAINEL
- 🗑️ Apagar Dados: Remove todos os registros

IMPORTANTE:
- Feche os arquivos Excel antes de executar
- Apenas linhas com fundo verde na coluna A serão processadas
- Confirme as operações quando solicitado

Desenvolvido para Hacktown 2025
